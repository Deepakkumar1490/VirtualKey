package Virtualkey;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class addfile {

     void add() throws IOException {
          
    	  String path="C:\\Users\\deepak\\Documents\\Practice_Project\\src\\Virtualkey\\";
          Scanner sc=new Scanner(System.in);
          System.out.println("Enter the filename to add");
          String filename=sc.next();
          String finalpath=path+filename;
          File f=new File(finalpath);
          boolean b=f.createNewFile();
          if(b!=true) {
               System.out.println("file not created");
           }
          else {
               System.out.println("file created");
           }
      }
}