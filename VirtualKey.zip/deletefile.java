package Virtualkey;

import java.io.File;
import java.util.Scanner;

public class deletefile {
     
	 void delete() {
            String path="C:\\Users\\deepak\\Documents\\Practice_Project\\src\\Virtualkey\\";
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter the filename to delete");
            String filename=sc.next();
            String finalpath=path+filename;
            File f=new File(finalpath);
            f.delete();
            System.out.println("file gets deleted");
       }
}