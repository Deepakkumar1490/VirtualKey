package Virtualkey;

import java.io.File;
import java.io.IOException;

public class displayfile {
	
       void display() {
            String path="C:\\Users\\deepak\\Documents\\Practice_Project\\src\\Virtualkey\\";
            File f=new File(path);
            File filenames[]=f.listFiles();
            for(File ff:filenames) {
            System.out.println(ff.getName());
            }
      }
}