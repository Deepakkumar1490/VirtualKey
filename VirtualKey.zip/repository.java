package Virtualkey;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class repository {

public static void main(String[] args) throws IOException {

Scanner sc=new Scanner(System.in);
int a;
displayfile obj=new displayfile();
addfile obj1=new addfile();
deletefile obj2=new deletefile();
searchfile obj3=new searchfile();

do {
System.out.println("Operation to be performed \n1.DisplayFile \n2.Other Operations ");
int n=sc.nextInt();

switch(n){
case 1:
obj.display();
break;
case 2:do {
System.out.println("Enter the operation to be performed \n1.Add File \n2.Delete File \n3.Search File");
int Op=sc.nextInt();
switch(Op) {
       case 1:
       obj1.add();
       break;
       case 2:
            obj2.delete();
            break;
       case 3:
            obj3.search();
            break;


}
System.out.println("Do you want to continue?\n1.Yes \n2.No");
a=sc.nextInt();
}while(a==1);

}
System.out.println("Do you want to continue?\n1.Yes \n2.No");
a=sc.nextInt();

}while(a==1);
}
}