package Virtualkey;

import java.io.File;
import java.util.Scanner;

public class searchfile {
      
	void search() {
          String path="C:\\Users\\deepak\\Documents\\Practice_Project\\src\\Virtualkey\\";
          Scanner sc=new Scanner(System.in);
          System.out.println("enter the filename to search");
          String filename=sc.next();
          File f=new File(path);
          int flag=0;
          File filenames[]=f.listFiles();
          for(File ff:filenames) 
          {
          if(ff.getName().equals(filename)) 
          {
                flag=1;
                break;
          }
          else {
                flag=0;
          }
}


if(flag==1) {
System.out.println("file is found");
}
else {
System.out.println("file is not found");
}

}



}